const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
const Business = require('./models/Business');

app.use(express.json());

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log("✅ Connected to MongoDB Atlas"))
.catch(err => console.error("❌ MongoDB connection error:", err));

app.get('/api/business/:slug', async (req, res) => {
  try {
    const biz = await Business.findOne({ slug: req.params.slug });
    if (!biz) return res.status(404).json({ error: 'Business not found' });
    res.json(biz);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/business', async (req, res) => {
  const { slug, name, logo_url, thank_you_msg, employee_list, coupon_url } = req.body;
  if (!slug) return res.status(400).json({ error: "Slug is required" });

  try {
    const existing = await Business.findOne({ slug });
    if (existing) {
      await Business.updateOne({ slug }, { name, logo_url, thank_you_msg, employee_list, coupon_url });
      return res.json({ message: "Business updated" });
    } else {
      const biz = new Business({ slug, name, logo_url, thank_you_msg, employee_list, coupon_url });
      await biz.save();
      return res.status(201).json({ message: "Business created" });
    }
  } catch (err) {
    return res.status(500).json({ error: "Server error" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));